
          <h2><?php echo $sitename ?></h3>
          <p>Copyright &copy; 2016 - developed by <a href="http://juniordev.net">JuniorDev</a></p>
  </body>
</html>