<?php

header("location: https://katakanpadanya.tk");
exit;

