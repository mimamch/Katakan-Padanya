<?php


$php = file_get_contents("template.txt");
